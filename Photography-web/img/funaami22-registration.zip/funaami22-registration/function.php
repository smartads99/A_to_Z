<?php
session_start();
include 'config.php';
if(isset($_POST) && isset($_POST['type']) && !empty($_POST['type']) && $_POST['type']=='otp')
{
	$mobile = $_POST['mobilenumber'];
	if(isset($mobile) && !empty($mobile) && strlen($mobile)==10)
	{
		$sql = "SELECT * FROM events_customer where mobile_number='$mobile'";
		$result = $conn->query($sql);
		$result->rowCount();
		if ($result->rowCount()==0) {
			$otp = mt_rand(1000,9999);
			$_SESSION['otp'] = $otp;
			$url = "https://bhashsms.com/api/sendmsg.php?user=pragashyadhav&pass=achariya@2020&sender=ACHEDN&phone=$mobile&text=$mobile%20is%20your%20One%20time%20password%20$otp%20for%20registering%20to%20FUNAAMI%2722.%20OTP%20is%20usable%20only%20once.%20Please%20do%20not%20share%20it%20with%20anyone.&priority=ndnd&stype=normal";
			$result = CommonGetFunction($url);
			if(isset($result) && !empty($result))
			{
				echo "otp sent successfully";
			}else
			{
				echo "Invalid mobile Number";
			}
		}else
		{
			echo "Your Moblie Number Already Register";
		}
		
		
	}else
	{
		echo "Invalid mobile Number";
	}
}

if(isset($_POST) && isset($_POST['type']) && !empty($_POST['type']) && $_POST['type']=='otpverified')
{
	$otp = $_POST['otp'];
	if(isset($otp) && !empty($otp) && strlen($otp)==4)
	{
		if($otp==$_SESSION['otp'])
		{
			echo "otp Verified successfully";
		}else
		{
			echo "Invalid OTP";
		}
		
	}else
	{
		echo "Invalid OTP";
	}
}

if(isset($_POST) && isset($_POST['type']) && !empty($_POST['type']) && $_POST['type']=='formsave')
{
	//$otp = $_POST['otp'];
	if(isset($_POST) && !empty($_POST))
	{
		$name = $_POST['Student_Name'];
		$calss = $_POST['Present_Class'];
		$school = $_POST['Present_School'];
		$fathername = $_POST['Father_Name'];
		$mobile = $_POST['Mobile_Number1'];
		$refer_code = $_POST['refer_code'];
		$Achariyan = $_POST['Achariyan'];
		$age = $_POST['age'];
		$create_date = date('y-m-d h:i:s');
		$sql = "INSERT INTO events_customer (name, age, class,achariyan,school_name,father_name,refer_id,create_date,mobile_number)
		VALUES ('$name', '$age', '$calss','$Achariyan','$school','$fathername','$refer_code','$create_date','$mobile')";

		if ($conn->query($sql)) {
		  $last_id = $conn->lastInsertId();
		  $last_id = 1000+$last_id;
		  $refer_code = "FUN$last_id";
		 // $url ="https://bhashsms.com/api/sendmsg.php?user=pragashyadhav&pass=achariya@2020&sender=ACHEDN&phone=$mobile&text=Congratulations%20Your%20Tickets%20for%20FUNAAMI%2722%20are%20booked!%20Your%20Ticket%20ID%20is%20$refer_code.%20Simply%20show%20this%20message%20at%20the%20entry%20counter%20to%20enter.%20Your%20FUNAAMI%2722%20is%20on%2008%20May,2022%203%20PM%20at%20ACHARIYA%20Bala%20Siksha%20Mandir,%20Thengathittu.%20T%26C%20apply.&priority=ndnd&stype=normal";
		  
		   $url ="https://bhashsms.com/api/sendmsg.php?user=pragashyadhav&pass=achariya@2020&sender=ACHEDN&phone=$mobile&text=Congratulations%20Your%20Tickets%20for%20FUNAAMI%2722%20are%20booked!%20Your%20Ticket%20ID%20is%20$refer_code.%20Simply%20show%20this%20message%20at%20the%20entry%20counter%20to%20enter.%20Your%20FUNAAMI%2722%20is%20on%204%20June,2022%204%20PM%20at%20ACHARIYA%20Siksha%20Mandir%20CBSE%20School,Sathanur%20Main%20Road,%20KK%20Nagar,Trichy.%20T%26C%20apply.&priority=ndnd&stype=normal";
			$result = CommonGetFunction($url);
		 //$url1 = "https://bhashsms.com/api/sendmsg.php?user=pragashyadhav&pass=achariya@2020&sender=ACHEDN&phone=$mobile&text=Dear%20$name%20thank%20you%20for%20successfully%20registering%20to%20FUNAAMI%2722%20at%20ACHARIYA.%20Happily%20refer%205%20of%20your%20friends%20with%20your%20unique%20Referral%20code%20$refer_code%20and%20Stand%20a%20chance%20to%20win%20Exciting%20Prizes%20if%20all%206%20of%20you%20come%20for%20FUNAAMI%E2%80%9922,%20on%2008%20May,2022%204%20PM%20Share%20this%20link%20for%20registration%20https://achariya.in/funaami22-registration&priority=ndnd&stype=normal";
		//$result = CommonGetFunction($url1);
		
		  
		} else {
		  
		}

	
	}
}

function CommonGetFunction($URL)
{
	//echo $URL;
	 $headers = array

        (

		'Content-Type: text/html'

       );
	$ch = curl_init();  
	curl_setopt($ch,CURLOPT_URL,$URL);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_HTTPHEADER, $headers );
 
    $output=curl_exec($ch);
	curl_close($ch);
	return $output;
	
	
	
}
?>