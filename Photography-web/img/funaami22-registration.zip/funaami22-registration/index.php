<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Funaami 22">
    <meta name="author" content="Funaami 22">
    <meta name="keywords" content="Funaami 22">

    <!-- Title Page-->
    <title>FUNAAMI 22 Registration</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>
<style>
.error-label
{
	color:red;
}
input {
    border: 1px solid #999!important;
}
</style>
<body>
    <div class="page-wrapper bg-gra-02 font-poppins">
	
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body" style="padding-top: 0px;">
					<div class="col-12">
						<img src="fun.jpg" style="width:100%">
					</div>
                    <h2 class="title">Registration Form</h2>
					<div class="row row-space mobileverified">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Mobile Number</label>
                                    <input class="input--style-4" type="number" name="mobile_number" id="mobile_number">
									 <label class="error-label mobile_number_error" style="display:none;">Mobile Number Required</label>
                                </div>
                            </div>
							 <div class="col-2" style="display:none;" id="otpshow">
                                <div class="input-group">
                                    <label class="label">Enter OTP</label>
                                    <input class="input--style-4" type="number" name="otp" id="otp">
									<label class="error-label otp_error" style="display:none;">OTP Required</label>
                                </div>
                            </div>
                         <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="button" onclick="getotp()" id="getotp">Get OTP</button>
                            <button class="btn btn--radius-2 btn--blue" type="button" onclick="verifiedotp()" id="verifiedotp" style="display:none">Verify OTP</button>
                        </div>   
                    </div>
						
                    <form method="POST" style="display:none" id="formshow">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Student Name</label>
                                    <input class="input--style-4" type="text" name="Student_Name" id="Student_Name">
									<label class="error-label Student_Name_error" style="display:none;">Student Name Required</label>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Father Name</label>
                                    <input class="input--style-4" type="text" name="Father_Name" id="Father_Name">
									<label class="error-label Father_Name_error" style="display:none;">Father Name Requried</label>
                                </div>
                                
                            </div>
                        </div>
						<div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Achariyan</label>
                                    <div class="p-t-10">
                                        <label class="radio-container m-r-45">Yes
                                            <input type="radio" name="Achariyan" value="Yes">
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="radio-container">No
                                            <input type="radio" name="Achariyan" value="No">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Present School </label>
                                    <input class="input--style-4" type="text" name="Present_School" id="Present_School">
									<label class="error-label Present_School_error" style="display:none;">Present School Requried</label>
                                </div>
							
								
                            </div>
                        </div>
						
						<div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Present Class</label>
                                    <input class="input--style-4" type="text" name="Present_Class" id="Present_Class">
									<label class="error-label Present_Class_error" style="display:none;">Present Class Required</label>
                                </div>
                                
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                            <label class="label">Age</label>
                            <div class="rs-select2 js-select-simple select--no-search">
                                <select name="age" id='age'>
                                    <option value="" disabled="disabled" selected="selected">Choose Age</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                    <option value="12">12</option>
                                    <option value="13">13</option>
                                    <option value="14">14</option>
                                </select>
                                <div class="select-dropdown"></div>
                            </div>
							<label class="error-label ade_error" style="display:none;">Age Requried</label>
                        </div>
                            </div>
                        </div>
						
						<div class="row row-space">
							<div class="col-2">
							    <div class="input-group">
                                    <label class="label">Referral Code</label>
                                    <input class="input--style-4" type="text" name="refer_code" id="refer_code">
                                    <p>Enter Only Valid Referral Code</p>
                                </div>
                                
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Mobile Number </label>
                                    <input class="input--style-4" type="text" name="Mobile_Number1" id="Mobile_Number1" readonly>
                                </div>
                            </div>
                        </div>
                        
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="button" onclick="formSubmit()">Submit</button>
                        </div>
                    </form>
                    
                    <p><!-- hitwebcounter Code START -->
<a href="#" target="_blank">
<img src="https://hitwebcounter.com/counter/counter.php?page=7991110&style=0010&nbdigits=6&type=ip&initCount=0" title="Free Counter" Alt="web counter"   border="0" /></a>     </p>
                </div>
            </div>
            
        </div>
    </div>

	<script src="vendor/select2/select2.min.js"></script>
    <!-- Main JS-->
    <script src="js/global.js"></script>
	
	<script>
	
	
	function getotp()
	{
		var mobilenumber = $('#mobile_number').val();
		
	    if(mobilenumber!='')
		{
			
			$.ajax({
               type: "post",
               url: 'function.php',
               data: {
                    mobilenumber: mobilenumber,
					type:"otp",
                },
                   success: function (data) {
					
					alert(data);
					if(data=='otp sent successfully')
					{
						
						$('#verifiedotp').show();
						$('#otpshow').show();
						$('#getotp').hide();
						$('.mobile_number_error').hide();
					}
               }
            });
			
		}else
		{
			$('.mobile_number_error').show();
		}
		
	}
	function verifiedotp()
	{
		var otp = $('#otp').val();
		if(otp!='')
		{
			
			$.ajax({
               type: "post",
               url: 'function.php',
               data: {
                    otp: otp,
					type:"otpverified",
                },
                   success: function (data) {
					alert(data);
					if(data=='otp Verified successfully')
					{
						$('#formshow').show();
						$('.mobileverified').hide();
						$('#Mobile_Number1').val($('#mobile_number').val());
					}
               }
            });
			
		}else
		{
			$('.otp_error').show();
		}
		
	}
	
	function formSubmit()
	{
		var Name = $('#Student_Name').val();
		var pclass = $('#Present_Class').val();
		var school = $('#Present_School').val();
		var Father = $('#Father_Name').val();
		var age = $('#age').val();
		  
		if(Name=='')
		{
			$('.Student_Name_error').show();
			return false;
		}
		if(pclass=='')
		{
			$('.Present_Class_error').show();
			return false;
		}
		if(school=='')
		{
			$('.Present_School_error').show();
			return false;
		}if(Father=='')
		{
			$('.Father_Name_error').show();
			return false;
		}if(age=='')
		{
			$('.age_error').show();
			return false;
		}
		
		$.ajax({
               type: "post",
               url: 'function.php',
               data: {
                    Student_Name: Name,
                    Present_Class: pclass,
                    Present_School: school,
                    Father_Name: Father,
                    Mobile_Number1: $('#Mobile_Number1').val(),
                    refer_code: $('#refer_code').val(),
                    Achariyan: $('input[name="Achariyan"]:checked').val(),
                    age: $('#age').val(),
					type:"formsave",
                },
                   success: function (data) {
					alert('Successfully Registered');
					location.reload();
					
               }
            });
	}
	</script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->