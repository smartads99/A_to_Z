<?php
include 'config.php';

$sql = "SELECT * FROM events_customer group by mobile_number";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>ACHARIYA Bala Siksha Mandir</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet" media="all">
    <link href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css" rel="stylesheet" media="all">


    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>

</head>
<style>
.error-label
{
	color:red;
}
input {
    border: 1px solid #999!important;
}
</style>
<body>
    <div class="container">
	<div class="col-12">
		<img src="fun.jpg" style="height:10%">
	</div>
		<div class="col-12">
       <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th style="text-align: left;">Ticket No</th>
                <th style="text-align: left;">Name</th>
                <th style="text-align: left;">Age</th>
                <th style="text-align: left;">Mobile Number</th>
                <th style="text-align: left;">Class</th>
                <th style="text-align: left;">Achariyan</th>
				<th style="text-align: left;">Referral Code</th>
                <th style="text-align: left;">School</th>
                <th style="text-align: left;">Father Name</th>
                <th style="text-align: left;">Create Date</th>
            </tr>
        </thead>
        <tbody>
		<?php 
		if ($result->rowCount() > 0) {
			  // output data of each row
			  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
				$fun = 1000+$row["id"];
			  
			?>
            <tr>
				<td><?php echo "FUN".$fun; ?></td>
                <td><?php echo $row["name"]; ?></td>
                <td><?php echo $row["age"]; ?></td>
                <td><?php echo $row["mobile_number"]; ?></td>
                <td><?php echo $row["class"]; ?></td>
                <td><?php echo $row["achariyan"]; ?></td>
                <td><?php echo $row["refer_id"]; ?></td>
                <td><?php echo $row["school_name"]; ?></td>
                <td><?php echo $row["father_name"]; ?></td>
                <td><?php echo $row["create_date"]; ?></td>
            </tr>
			
			<?php 
			}
} else {
  
}
?>
        </tbody>
    </table>
    </div>
    </div>

    <!-- Main JS-->
    <script src="js/global.js"></script>
	
<script>

$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ]
    } );
} );

</script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->